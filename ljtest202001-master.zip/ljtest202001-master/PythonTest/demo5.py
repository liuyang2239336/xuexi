
a = 11
b = 2
print(a+b)
print(a-b)
print(a*b)
print(a/b)  # 保留小数点
print(a//b) # 不要小数点，除数的结果取整
print(a%b)  # 取余数

if a/2>5:
    print("成立！")

