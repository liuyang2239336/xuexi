# 包
import time # 导入包
import os
import random 